#include <stdio.h>
#include <stdlib.h>

int main(void) {
//	printf("  %c%c", a2, 0xdf);
//	char a = '+', b = '+';
//	scanf("%c", &a);
//	b = a;
//	printf("%c", b);
//	
	long number = 0, count1 = 0;
	
	scanf("%ld", &number);
	
	while (number != 0) {
		number = number/10;
		++count1;
	}
	
	if (number == 0 || count1 > 9)
		exit(0);
	
	printf("%ld", number);
}
