#include <stdio.h>
#include <conio.h>
int main(void)
{
   char chr;
   do
   {
	printf("�ش� Ű�� �����ÿ�>");
	chr=getch();
	printf("\nŰ: %c, ASCII(10):%d, (16):%x\n", chr, chr, chr); //each key's ascii & hexadecimal
   }while(chr!='0'); //if 0 break
   return 0;
}
